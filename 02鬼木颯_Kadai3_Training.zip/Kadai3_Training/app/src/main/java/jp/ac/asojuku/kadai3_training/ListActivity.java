package jp.ac.asojuku.kadai3_training;

import android.database.sqlite.SQLiteCursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

public class ListActivity extends AppCompatActivity {
    private SQLiteDatabase sqlDB;
    DBManager dbm;

    int selectedID = -1;
    int lastPosition = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Button back = (Button)findViewById(R.id.buttonback);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        Button delete =(Button)findViewById(R.id.buttonDelete);
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (lastPosition != -1){
                    dbm.deleteWord(sqlDB,selectedID);

                    ListView listWord = (ListView)findViewById(R.id.listViewWord);
                    setValueToList(listWord);

                    selectedID = -1;
                    lastPosition = -1;
                }else {
                    Toast.makeText(getApplicationContext(),"削除する行を選んでください",Toast.LENGTH_LONG).show();
                }
            }
        });

        ListView listword = (ListView)findViewById(R.id.listViewWord);
        listword.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (selectedID != -1){

                    parent.getChildAt(lastPosition).setBackgroundColor(0);
                }

                view.setBackgroundColor(getResources().getColor(R.color.tap_color));
                SQLiteCursor cursor = (SQLiteCursor)parent.getItemAtPosition(position);

                selectedID = cursor.getInt(cursor.getColumnIndex("_id"));

                lastPosition = position;

            }
        });
        setValueToList(listword);
    }

    private void setValueToList(ListView list){
        SQLiteCursor cursor = null;

        dbm = new DBManager(this);
        sqlDB = dbm.getWritableDatabase();
        cursor = dbm.selectWord(sqlDB);

        int dblayout = android.R.layout.simple_list_item_1;

        String[] from = {"phrase"};

        int[] to = new int[]{android.R.id.text1};

        SimpleCursorAdapter adapter = new SimpleCursorAdapter(this,dblayout,cursor,from,to,0);

        list.setAdapter(adapter);
    }
}
