package jp.ac.asojuku.kadai3_training;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class EatActivity extends AppCompatActivity {
    private int hungry;
    private int muscle;
    private int weight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eat);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Intent intent = getIntent();
        hungry = intent.getIntExtra("hungry",0);
        muscle = intent.getIntExtra("muscle",0);
        weight = intent.getIntExtra("weight",0);

        TextView hungrytextView = (TextView)findViewById(R.id.textViewHungry);
        hungrytextView.setText(String.valueOf(hungry)+"%");

        TextView muscletextView = (TextView)findViewById(R.id.textViewMuscle);
        muscletextView.setText(String.valueOf(muscle)+"%");

        TextView weighttextView = (TextView)findViewById(R.id.textViewWeight);
        weighttextView.setText(String.valueOf(weight)+"kg");



        ImageView riceImage = (ImageView)findViewById(R.id.riceimageView);
        riceImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EatActivity.this, EatingActivity.class);
                intent.putExtra("add",10);
                intent.putExtra("inc",1);
                intent.putExtra("hungry",hungry);
                intent.putExtra("muscle", muscle);
                intent.putExtra("weight",weight);
                startActivity(intent);
            }
        });

        ImageView panImage = (ImageView)findViewById(R.id.panimageView);
        panImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EatActivity.this, EatingActivity.class);
                intent.putExtra("add",20);
                intent.putExtra("inc",1);
                intent.putExtra("hungry",hungry);
                intent.putExtra("muscle", muscle);
                intent.putExtra("weight",weight);
                startActivity(intent);
            }
        });

        ImageView steakImage = (ImageView)findViewById(R.id.steakimageView);
        steakImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EatActivity.this, EatingActivity.class);
                intent.putExtra("add",40);
                intent.putExtra("inc",3);
                intent.putExtra("hungry",hungry);
                intent.putExtra("muscle", muscle);
                intent.putExtra("weight",weight);
                startActivity(intent);
            }
        });

        ImageView sushiImage = (ImageView)findViewById(R.id.sushiimageView);
        sushiImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EatActivity.this, EatingActivity.class);
                intent.putExtra("add",30);
                intent.putExtra("inc",2);
                intent.putExtra("hungry",hungry);
                intent.putExtra("muscle", muscle);
                intent.putExtra("weight",weight);
                startActivity(intent);
            }
        });

        Button backButton = (Button)findViewById(R.id.backbutton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EatActivity.this, MainActivity.class);
                intent.putExtra("hungry",hungry);
                intent.putExtra("muscle", muscle);
                intent.putExtra("weight",weight);
                startActivity(intent);
            }
        });
    }
}
