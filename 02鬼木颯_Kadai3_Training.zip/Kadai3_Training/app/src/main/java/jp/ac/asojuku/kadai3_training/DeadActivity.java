package jp.ac.asojuku.kadai3_training;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class DeadActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dead);
    }

    @Override
    protected void onResume() {
        super.onResume();

        Button birthButton = (Button)findViewById(R.id.birthbutton);
        birthButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DeadActivity.this, MainActivity.class);
                intent.putExtra("hungry",50);
                intent.putExtra("muscle", 10);
                intent.putExtra("weight",50);

                startActivity(intent);


            }
        });


    }
}
