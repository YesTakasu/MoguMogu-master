package jp.ac.asojuku.kadai3_training;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MovingActivity extends AppCompatActivity {
    private int hungry;
    private int muscle;
    private int weight;
    private int add;
    private int update;
    private int update2;
    private int dec;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_moving);
    }

    @Override
    protected void onResume() {
        super.onResume();

        Intent intent = getIntent();
        add = intent.getIntExtra("add",0);
        dec = intent.getIntExtra("dec",0);
        muscle = intent.getIntExtra("muscle",0);
        hungry = intent.getIntExtra("hungry",0);
        weight = intent.getIntExtra("weight",0);

        update = muscle + add;
        update2 = hungry - dec;


        TextView muscleText = (TextView)findViewById(R.id.muscletextView);
        muscleText.setText(String.valueOf(muscle)+"%");

        TextView updatetext = (TextView)findViewById(R.id.updatetextView);
        updatetext.setText(String.valueOf(update)+"%");

        TextView hungryText = (TextView)findViewById(R.id.hungrytextView);
        hungryText.setText(String.valueOf(hungry)+"%");

        TextView updatetext2 = (TextView)findViewById(R.id.updatetextView2);
        updatetext2.setText(String.valueOf(update2)+"%");

        Button backButton = (Button)findViewById(R.id.backbutton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MovingActivity.this, MoveActivity.class);
                intent.putExtra("muscle",update);
                intent.putExtra("hungry",update2);
                intent.putExtra("weight",weight);
                startActivity(intent);
            }
        });



    }
}
