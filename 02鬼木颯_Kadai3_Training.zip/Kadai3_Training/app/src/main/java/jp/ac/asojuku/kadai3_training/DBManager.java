package jp.ac.asojuku.kadai3_training;

import android.content.Context;
import android.database.sqlite.SQLiteCursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBManager extends SQLiteOpenHelper {
    public DBManager(Context context){
        super(context,"1601116.sqlite3",null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS word(_id INTEGER PRIMARY KEY AUTOINCREMENT,phrase TEXT)");


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE word");
        onCreate(db);
    }

    public  void  insertWord(SQLiteDatabase sqLiteDatabase, String inputMessage){
        String sql = "INSERT INTO word(phrase) VALUEs(?)";
        sqLiteDatabase.execSQL(sql,new String[]{inputMessage});
    }






    public String selectWordRandom(SQLiteDatabase sqLiteDatabase){
        String result = null;
        String select = "SELECT * FROM word ORDER BY RANDOM()";

        SQLiteCursor cursor =(SQLiteCursor)sqLiteDatabase.rawQuery(select,null);
        if (cursor.getCount() != 0){
            cursor.moveToFirst();
            result=cursor.getString(1);
        }
        cursor.close();
        return result;
    }
    public SQLiteCursor selectWord(SQLiteDatabase sqLiteDatabase){
        String selectSql = "SELECT * FROM word ORDER BY _id";
        SQLiteCursor cursor = (SQLiteCursor)sqLiteDatabase.rawQuery(selectSql,null);
        return  cursor;
    }


    public  void  deleteWord(SQLiteDatabase sqLiteDatabase, int id){
        String deleteSql = "DELETE FROM word WHERE _id = ?";
        sqLiteDatabase.execSQL(deleteSql, new String[]{String.valueOf(id)});
    }
}
