package jp.ac.asojuku.kadai3_training;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Handler;
import android.os.PersistableBundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
    private SQLiteDatabase sqlDB;
    DBManager dbm;
    private TextView textViewHungry;
    private int hungry = 50;
    private Timer timer;
    private Handler handler = new Handler();
    private TextView textViewWeight;
    private int weight;
    private TextView textViewMuscle;
    private int muscle;
    private  int count;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textViewHungry = (TextView)findViewById(R.id.textViewHungry);
        textViewMuscle = (TextView)findViewById(R.id.textViewMuscle);
        textViewWeight = (TextView)findViewById(R.id.textViewWeight);

        dbm = new DBManager(this);
        sqlDB = dbm.getWritableDatabase();




    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Intent intent2 = new Intent(getApplication(),BackService.class);
        stopService(intent2);

    }

    @Override
    protected void onResume() {
        super.onResume();


        Intent intent = getIntent();
        hungry = intent.getIntExtra("hungry",hungry);
        muscle = intent.getIntExtra("muscle",10);
        weight = intent.getIntExtra("weight",50);

        TextView hungrytextView = (TextView)findViewById(R.id.textViewHungry);
        hungrytextView.setText(String.valueOf(hungry)+"%");

        TextView muscletextView = (TextView)findViewById(R.id.textViewMuscle);
        muscletextView.setText(String.valueOf(muscle)+"%");

        TextView weighttextView = (TextView)findViewById(R.id.textViewWeight);
        weighttextView.setText(String.valueOf(weight)+"kg");

        Button teachButton =(Button)findViewById(R.id.teachbutton);
        teachButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, TeachActivity.class);
                intent.putExtra("hungry",hungry);
                intent.putExtra("muscle", muscle);
                intent.putExtra("weight",weight);
                startActivity(intent);

            }
        });

        Button eatButton =(Button)findViewById(R.id.eatbutton);
        eatButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, EatActivity.class);
                intent.putExtra("hungry",hungry);
                intent.putExtra("muscle", muscle);
                intent.putExtra("weight",weight);
                startActivity(intent);

            }
        });


        Button moveButton = (Button)findViewById(R.id.movebutton);
        moveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,MoveActivity.class);
                intent.putExtra("muscle", muscle);
                intent.putExtra("hungry",hungry);
                intent.putExtra("weight",weight);
                startActivity(intent);
            }
        });



        TextView wordTextview = (TextView)findViewById(R.id.wordtextView);
        wordTextview.setText(dbm.selectWordRandom(sqlDB));

        timeStart();

    }

    private void timeStart(){

        timer = new Timer(true);
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        hungry--;
                        if (hungry <= 0){
                            characterDead();
                        }
                        textViewHungry.setText(hungry+"%");
                    }
                });
            }
        },0,10000);

    }

    private  void characterDead(){
        Intent intent = new Intent(MainActivity.this, DeadActivity.class);
        startActivity(intent);


    }

    @Override
    protected void onPause() {
        super.onPause();
        Intent intent = new Intent(getApplication(),BackService.class);
        intent.putExtra("hungry",hungry);

    }

    @Override
    protected void onStop() {
        super.onStop();
        Intent intent = new Intent(getApplication(),BackService.class);
        intent.putExtra("hungry",hungry);

        startService(intent);
    }
}
