package jp.ac.asojuku.kadai3_training;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;

import java.util.Timer;
import java.util.TimerTask;

public class BackService extends Service {
    private int hungry;
    private Timer timer;
    private Handler handler = new Handler();

    public BackService() {
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {


        hungry = intent.getIntExtra("hungry",0);




        timer = new Timer(true);
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        hungry--;
                    }
                });
            }
        },1,10000);
        Intent intent2 = new Intent(this, MainActivity.class);
        intent.putExtra("hungry",hungry);

        return super.onStartCommand(intent, flags, startId);



    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("hungry",hungry);

    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;


    }
}
