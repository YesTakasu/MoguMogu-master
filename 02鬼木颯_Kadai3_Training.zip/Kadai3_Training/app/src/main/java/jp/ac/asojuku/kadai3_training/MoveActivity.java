package jp.ac.asojuku.kadai3_training;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MoveActivity extends AppCompatActivity {
    private int hungry;
    private int muscle;
    private int weight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_move);
    }

    @Override
    protected void onResume() {
        super.onResume();

        Intent intent = getIntent();
        hungry = intent.getIntExtra("hungry",0);
        muscle = intent.getIntExtra("muscle",0);
        weight = intent.getIntExtra("weight",0);

        TextView hungrytextView = (TextView)findViewById(R.id.textViewHungry);
        hungrytextView.setText(String.valueOf(hungry)+"%");

        TextView muscletextView = (TextView)findViewById(R.id.textViewMuscle);
        muscletextView.setText(String.valueOf(muscle)+"%");

        TextView weighttextView = (TextView)findViewById(R.id.textViewWeight);
        weighttextView.setText(String.valueOf(weight)+"kg");



        Button udeButton = (Button)findViewById(R.id.udebutton);
        udeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MoveActivity.this,MovingActivity.class);
                intent.putExtra("muscle",muscle);
                intent.putExtra("hungry",hungry);
                intent.putExtra("weight",weight);
                intent.putExtra("add",2);
                intent.putExtra("dec",30);
                startActivity(intent);
            }
        });

        Button hukButton = (Button)findViewById(R.id.hukubutton);
        hukButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MoveActivity.this,MovingActivity.class);
                intent.putExtra("muscle",muscle);
                intent.putExtra("hungry",hungry);
                intent.putExtra("weight",weight);
                intent.putExtra("add",1);
                intent.putExtra("dec",20);
                startActivity(intent);
            }
        });

        Button walkButton = (Button)findViewById(R.id.walkbutton);
        walkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MoveActivity.this,WalkActivity.class);
                intent.putExtra("muscle",muscle);
                intent.putExtra("hungry",hungry);
                intent.putExtra("weight",weight);
                startActivity(intent);
            }
        });

        Button backButton = (Button)findViewById(R.id.backbutton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MoveActivity.this, MainActivity.class);
                intent.putExtra("hungry",hungry);
                intent.putExtra("muscle", muscle);
                intent.putExtra("weight",weight);
                startActivity(intent);
            }
        });

    }
}
