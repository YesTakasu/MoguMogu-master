package jp.ac.asojuku.kadai3_training;

import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class WalkActivity extends AppCompatActivity implements SensorEventListener {
    private int hungry;
    private int muscle;
    private int weight;
    private SensorManager sensorManager;
    private TextView textView, textInfo;
    private int count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_walk);

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);

        textInfo = findViewById(R.id.text_info);



    }

    @Override
    protected void onResume() {
        super.onResume();
        Intent intent = getIntent();
        hungry = intent.getIntExtra("hungry",0);
        muscle = intent.getIntExtra("muscle",0);
        weight = intent.getIntExtra("weight",0);

        TextView hungrytextView = (TextView)findViewById(R.id.textViewHungry);
        hungrytextView.setText(String.valueOf(hungry)+"%");

        TextView muscletextView = (TextView)findViewById(R.id.textViewMuscle);
        muscletextView.setText(String.valueOf(muscle)+"%");

        TextView weighttextView = (TextView)findViewById(R.id.textViewWeight);
        weighttextView.setText(String.valueOf(weight)+"kg");


        Sensor accel = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        sensorManager.registerListener(this,accel,SensorManager.SENSOR_DELAY_NORMAL);

        Button backButton = (Button)findViewById(R.id.backbutton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(WalkActivity.this, MoveActivity.class);
                intent.putExtra("hungry",hungry);
                intent.putExtra("muscle", muscle);
                intent.putExtra("weight",weight);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        float sensorX,sensorY,sensorZ;

        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER){
            sensorX = event.values[0];
            sensorY = event.values[1];
            sensorZ = event.values[2];

           // String srtTmp = "加速度センサー\n"+"X:"+sensorX+"\n"+"Y:"+sensorY+"\n"+"Z:"+sensorZ;
            //textView.setText(srtTmp);

            if(sensorX>20||sensorY>20||sensorZ>20){
                count=count+1;
                if (count%10==0){
                    hungry = hungry-1;
                }
                if(count%20==0){
                    weight = weight-1;
                }
                if (count%30==0){
                    muscle = muscle+1;
                }
            }
            textInfo.setText(String.valueOf(count)+"歩");
            TextView hungrytextView = (TextView)findViewById(R.id.textViewHungry);
            hungrytextView.setText(String.valueOf(hungry)+"%");
            TextView weighttextView = (TextView)findViewById(R.id.textViewWeight);
            weighttextView.setText(String.valueOf(weight)+"%");
            TextView muscletextView = (TextView)findViewById(R.id.textViewMuscle);
            muscletextView.setText(String.valueOf(muscle)+"%");




            showInfo(event);
        }
    }

    private  void  showInfo(SensorEvent event){

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}
