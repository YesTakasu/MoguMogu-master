package jp.ac.asojuku.kadai3_training;

import android.app.ListActivity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class TeachActivity extends AppCompatActivity {

    private SQLiteDatabase sqlDB;
    DBManager dbm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teach);
    }

    @Override
    protected void onResume() {
        super.onResume();
        dbm = new DBManager(this);
        sqlDB = dbm.getWritableDatabase();

        final EditText word = (EditText)findViewById(R.id.editTextword);
        Button buttonInsert = (Button)findViewById(R.id.buttonInsert);

        buttonInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = word.getText().toString();

                if (message != null)dbm.insertWord(sqlDB,message);

                word.setText("");
                Toast.makeText(getApplicationContext(),"コトバを覚えました", Toast.LENGTH_LONG).show();
            }
        });

        Button buttonlist = (Button)findViewById(R.id.buttonlist);
        buttonlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TeachActivity.this, jp.ac.asojuku.kadai3_training.ListActivity.class);
                startActivity(intent);
            }
        });

        Button backButton = (Button)findViewById(R.id.backbutton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TeachActivity.this, MainActivity.class);
                 startActivity(intent);
            }
        });


    }

    @Override
    protected void onPause() {
        super.onPause();
        sqlDB.close();
    }
}
