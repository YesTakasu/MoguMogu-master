package jp.ac.asojuku.kadai3_training;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

public class RebornActivity extends AppCompatActivity {
    private SQLiteDatabase sqlDB;
    DBManager dbm;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reborn);
    }

    @Override
    protected void onResume() {
        super.onResume();
        dbm.deleteWord(sqlDB,1);
        Toast.makeText(getApplicationContext(),"新しい生命が誕生した", Toast.LENGTH_LONG).show();

        Intent intent = new Intent(RebornActivity.this, RebornActivity.class);
        intent.putExtra("muscle",10);
        intent.putExtra("hungry",50);
        intent.putExtra("weight",50);
        startActivity(intent);
    }
}
